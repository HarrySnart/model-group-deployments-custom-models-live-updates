from .model import SquareModel
